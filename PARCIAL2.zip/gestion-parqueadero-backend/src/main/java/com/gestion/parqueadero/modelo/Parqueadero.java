package com.gestion.parqueadero.modelo;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

@Entity
@Table(name = "parqueadero")
public class Parqueadero {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long id;

	@Column(name = "placa", length = 6, nullable = false, unique = true)
	private String placa;

	@Column(name = "entrada", length = 12, nullable = false)
	private String entrada;

	@Column(name = "salida", length = 12, nullable = false)
	private String salida;

	@Column(name = "ubicacion", length = 60, nullable = false)
	private String ubicacion;

	@Column(name = "vehiculo", length = 60, nullable = false)
	private String vehiculo;


	public Parqueadero(Long id, String placa, String entrada, String salida, String ubicacion, String vehiculo) {
		super();
		this.id = id;
		this.placa = placa;
		this.entrada = entrada;
		this.salida = salida;
		this.ubicacion = ubicacion;
		this.vehiculo = vehiculo;
		
	}


	public Long getId() {
		return id;
	}


	public void setId(Long id) {
		this.id = id;
	}


	public String getPlaca() {
		return placa;
	}


	public void setPlaca(String placa) {
		this.placa = placa;
	}


	public String getEntrada() {
		return entrada;
	}


	public void setEntrada(String entrada) {
		this.entrada = entrada;
	}


	public String getSalida() {
		return salida;
	}


	public void setSalida(String salida) {
		this.salida = salida;
	}


	public String getUbicacion() {
		return ubicacion;
	}


	public void setUbicacion(String ubicacion) {
		this.ubicacion = ubicacion;
	}


	public String getVehiculo() {
		return vehiculo;
	}


	public void setVehiculo(String vehiculo) {
		this.vehiculo = vehiculo;
	}
}
	
